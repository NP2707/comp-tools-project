GitSkills prototype artifact

Data source: the pinned GitHub sample, not the full Zenodo corpus.
Start with README.md, notebooks/01_gitskills.ipynb, or artifacts/gitskills-report.html.
The current run is results/sample-4000; results/sample preserves the earlier pilot.
Purpose clustering is in results/purpose, with an interactive artifacts/gitskills-purpose-explorer.html.
Read artifacts/gitskills-template-audit.html for the checked template-versus-task findings.
The audit includes separate assistant assessments and blank human-review fields.
Full raw audit text packets are omitted; regenerate them with scripts/run_template_audit.py.
The source, executed notebook, CSV outputs, figures, tests, dependency lock, and provenance are included.
Download the raw sample using scripts/download_sample.py; environments and raw data are not bundled.
SHA256SUMS.txt records every included file except itself.
